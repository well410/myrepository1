Docker-jenkins-sample
=====================

Sample Ruby RSpec application for testing Jenkins with Docker.

== Copyright James Turnbull 2014
